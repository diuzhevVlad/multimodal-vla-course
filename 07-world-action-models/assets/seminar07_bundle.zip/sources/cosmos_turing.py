"""Cosmos Policy LIBERO 2B inference on Turing, with full original weights.

Uses the pure PyTorch, name-compatible Cosmos DiT/Wan VAE port, all 28 blocks,
original modality injection/readout and original 2ab sampler. No model pruning.
This is a single-GPU inference adapter, not the NVIDIA distributed runtime.
"""
from pathlib import Path
from types import SimpleNamespace
import json, gc
import numpy as np
import torch
from einops import rearrange
from safetensors.torch import load_file
from wam_cosmos.dit import CosmosDiT
from wam_cosmos.wan_vae import WanVAE
from wam_cosmos.cosmos_sampler import CosmosPolicySampler
from wam_cosmos.denoiser_scaling import RectifiedFlowScaling
from wam_cosmos import reference as ref

SLOTS=['blank','current proprio','current wrist','current primary','actions',
       'future proprio','future wrist','future primary','value']

class CosmosPolicyTuring:
    def __init__(self,weights,data,device='cuda'):
        self.device=torch.device(device);self.data=Path(data)
        weights=Path(weights)
        checkpoint=torch.load(weights/'Cosmos-Policy-LIBERO-Predict2-2B.pt',map_location='cpu',weights_only=True,mmap=True)
        print('Checkpoint top-level:',list(checkpoint)[:5])
        sd=checkpoint.get('model',checkpoint)
        if 'state_dict' in sd:sd=sd['state_dict']
        self.checkpoint_keys=list(sd)
        net_sd={k.removeprefix('net.'):v for k,v in sd.items() if k.startswith('net.')}
        if not net_sd:net_sd=sd
        # _extra_state belongs to the TE runtime, not learned parameters.
        extra=[k for k in net_sd if k.endswith('_extra_state') or k.startswith('accum_')]
        self.excluded_runtime_keys=extra
        net_sd={k:v for k,v in net_sd.items() if k not in extra}
        with torch.device('meta'):self.net=CosmosDiT()
        self.net.load_state_dict(net_sd,strict=True,assign=True)
        del checkpoint,sd,net_sd
        self.net=self.net.to(device=self.device,dtype=torch.float32).eval().requires_grad_(False)
        self.vae=WanVAE.from_file(weights/'Wan2.1_VAE.pth',device=self.device,dtype=torch.float32)
        self.sampler=CosmosPolicySampler();self.scaling=RectifiedFlowScaling(1.0)
        self.params=sum(p.numel() for p in self.net.parameters())
        self.stats={k:np.asarray(v) for k,v in json.loads((self.data/'cosmos_statistics.json').read_text()).items()}
        self.texts=json.loads((self.data/'cosmos_text.json').read_text())
        self.text_embeddings={k:v.to(self.device) for k,v in load_file(str(self.data/'cosmos_text.safetensors')).items()}
        obs=dict(np.load(self.data/'cosmos_observation.npz'))
        self.obs=obs
        self.original,self.clean,self.images=self.prepare(obs)
        self.last_velocity=None

    @torch.inference_mode()
    def prepare(self,obs):
        cfg=SimpleNamespace(use_jpeg_compression=True,trained_with_image_aug=True)
        images=ref.prepare_images_for_model([obs['wrist_image'],obs['primary_image']],cfg)
        wrist,primary=images;blank=np.zeros_like(primary)
        seq=[blank]+[x for frame in [blank,wrist,primary,blank,blank,wrist,primary,blank] for x in [frame]*4]
        video=torch.from_numpy(np.stack(seq)).permute(3,0,1,2).unsqueeze(0).to(self.device).float()/127.5-1
        orig=self.vae.encode(video)
        clean=orig.clone()
        proprio=ref.rescale_proprio(obs['proprio'],self.stats)
        ref.replace_latent_with_proprio(clean,torch.tensor(proprio,device=self.device,dtype=torch.float32).reshape(1,-1),torch.tensor([1],device=self.device))
        return orig,clean,images

    @torch.inference_mode()
    def velocity(self,x,t,mask,text_index=0):
        # Input channels: 16 latent channels, condition mask, padding mask.
        x18=torch.cat([x,mask.expand(-1,1,-1,28,28),torch.zeros_like(mask).expand(-1,1,-1,28,28)],1)
        tokens=self.net.x_embedder(x18)
        B,T,H,W,D=tokens.shape
        rope=self.net.pos_embedder(T,H,W)
        groups=torch.arange(T,device=x.device).repeat_interleave(H*W)
        emb,lora=self.net.embed_timesteps(t)
        tokens=tokens.reshape(B,-1,D)
        context=self.text_embeddings[str(text_index)]
        if context.ndim==2:context=context[None]
        for block in self.net.blocks:tokens=block(tokens,context,rope,emb,lora,groups)
        out=self.net.final_layer(tokens,emb,lora,groups)
        return self.net.unpatchify(out.reshape(B,T,H,W,-1)).float()

    @torch.inference_mode()
    def sample(self,clean=None,conditioned=(0,1,2,3),seed=7,steps=5,text_index=0):
        clean=self.clean if clean is None else clean
        mask=torch.zeros(1,1,9,1,1,device=self.device);mask[:,:,list(conditioned)]=1
        # Match upstream arch_invariant_rand, including its NumPy RNG.
        noise=torch.from_numpy(np.random.RandomState(seed).standard_normal(clean.shape).astype(np.float32)).to(self.device)*80
        def denoiser(x,sigma):
            sigma=sigma.reshape(-1,1,1,1,1)
            cskip,cout,cin,t=self.scaling(sigma)
            inp=clean*mask+x*cin*(1-mask)
            times=(t*(1-mask)).squeeze((1,3,4))
            v=self.velocity(inp,times,mask,text_index)
            result=cskip*x+cout*v
            return result*(1-mask)+clean*mask
        result=self.sampler(denoiser,noise,num_steps=steps,sigma_min=4,sigma_max=80,solver_option='2ab')
        assert torch.isfinite(result).all(),'Non-finite Cosmos output'
        return result

    def actions(self,sample,physical=False):
        a=ref.extract_action_chunk_from_latent_sequence(sample,(16,7),torch.tensor([4],device=self.device))
        if physical:return ref.unnormalize_actions(a.cpu().numpy(),self.stats)
        return a

    def value(self,sample):
        return ref.extract_value_from_latent_sequence(sample,torch.tensor([8],device=self.device))

    @torch.inference_mode()
    def decode(self,sample,undo=True):
        sample=sample.clone()
        if undo:ref.undo_latent_injection(sample,self.original,[0,1,4,5])
        # Keep the entire causal prefix. Standalone decoding of slots 6/7 is incorrect.
        video=self.vae.decode(sample[:,:,:8]).clamp(-1,1)
        return ((video[0,:, [21,25]].permute(1,2,3,0)+1)*127.5).byte().cpu().numpy()

    def condition_on_actions(self,actions):
        clean=self.clean.clone()
        ref.replace_latent_with_action_chunk(clean,actions,torch.tensor([4],device=self.device))
        return clean

    def close(self):
        del self.net,self.vae,self.clean,self.original,self.text_embeddings
        gc.collect();torch.cuda.empty_cache()
