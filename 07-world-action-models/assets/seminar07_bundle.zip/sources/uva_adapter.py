"""Thin inference/visualization wrapper around the pinned, unmodified UVA model."""
from pathlib import Path
import gc, random
import numpy as np
import torch
import hydra, dill
from omegaconf import OmegaConf, open_dict
from unified_video_action.utils.data_utils import resize_image_eval, process_data, normalize_obs, extract_latent_autoregressive, unnormalize_future_action
from unified_video_action.env.pusht.pusht_image_env import PushTImageEnv


def seed_all(seed):
    random.seed(seed);np.random.seed(seed);torch.manual_seed(seed);torch.cuda.manual_seed_all(seed)

class UVALab:
    def __init__(self,weights,device='cuda',seed=100000):
        self.device=torch.device(device);self.seed=seed
        payload=torch.load(Path(weights)/'uva_pusht.ckpt',map_location='cpu',pickle_module=dill)
        cfg=payload['cfg'];OmegaConf.resolve(cfg)
        with open_dict(cfg):
            cfg.model.policy.vae_model_params.autoencoder_path=None
            cfg.model.policy.autoregressive_model_params.pretrained_model_path=None
        self.cfg=cfg
        print('UVA: full EMA state, 1 refinement iteration, 100 diffusion steps per head')
        self.policy=hydra.utils.instantiate(cfg.model.policy,task_name=cfg.task.name,
            task_modes=cfg.task.task_modes,normalizer_type=cfg.task.dataset.normalizer_type,
            language_emb_model=cfg.task.dataset.language_emb_model)
        state=payload['state_dicts']['ema_model']  # This released checkpoint contains EMA weights only.
        self.policy.load_state_dict(state,strict=True)
        del payload,state
        self.policy.to(self.device).eval().requires_grad_(False)
        self.model=self.policy.model
        self.params=sum(p.numel() for p in self.policy.parameters())
        self.env=self.new_env();self.initial=self.env.reset()
        self.history={k:torch.from_numpy(np.stack([v]*16)).float()[None].to(self.device) for k,v in self.initial.items()}
        self.cond,self.proprio=self.encode(self.history,seed=11)
        self.initial_rgb=np.moveaxis(self.initial['image'],0,-1)

    def new_env(self):
        env=PushTImageEnv(legacy=True,render_size=96,fix_goal=True)
        env.seed(self.seed)
        return env

    @torch.inference_mode()
    def encode(self,history,seed=11):
        seed_all(seed)
        obs={k:v.clone() for k,v in history.items()}
        obs=resize_image_eval(self.policy.task_name,obs)
        obs=normalize_obs(self.policy.normalizer,self.policy.normalizer_type,{'obs':obs})['obs']
        c,prop,_=process_data({'obs':obs},task_name=self.policy.task_name,eval=True,**self.policy.kwargs)
        c,_=extract_latent_autoregressive(self.policy.vae_model,c)
        return c,prop

    @torch.inference_mode()
    def predict(self,mode='policy_model',actions=None,future=None,seed=23,num_iter=1):
        seed_all(seed)
        params=self.policy.autoregressive_model_params
        z,a=self.model.sample_tokens(bsz=1,cond=self.cond.clone(),num_iter=num_iter,cfg=params.cfg,
            cfg_schedule=params.cfg_schedule,temperature=params.temperature,
            history_nactions=None,nactions=actions,proprioception_input={},task_mode=mode,
            vae_model=self.policy.vae_model,x=future)
        if z is not None:assert torch.isfinite(z).all()
        assert torch.isfinite(a).all()
        return z,a

    @torch.inference_mode()
    def decode(self,z):
        # Match upstream latent scale; decode one frame at a time to cap VRAM.
        return torch.cat([self.policy.vae_model.decode(frame[None]/0.2325) for frame in z]).clamp(-1,1).add(1).div(2).permute(0,2,3,1).cpu().numpy()

    def physical(self,a):
        return unnormalize_future_action(self.policy.normalizer,self.policy.normalizer_type,a).detach().cpu().numpy()[0]

    def simulate(self,a):
        env=self.new_env();env.reset();frames=[];rewards=[]
        for i,action in enumerate(self.physical(a)):
            obs,reward,done,info=env.step(action)
            rewards.append(float(reward))
            if i in (3,7,11,15):frames.append(np.moveaxis(obs['image'],0,-1))
        env.close()
        return np.stack(frames),np.asarray(rewards)

    @torch.inference_mode()
    def encode_future(self,frames):
        from PIL import Image
        x=np.stack([np.asarray(Image.fromarray((f*255).astype(np.uint8)).resize((256,256))) for f in frames])
        x=torch.tensor(x,device=self.device).permute(0,3,1,2).float()/127.5-1
        seed_all(11)
        return self.policy.vae_model.encode(x).sample().mul(0.2325)[None]

    def close(self):
        self.env.close();del self.model,self.policy,self.cond,self.proprio,self.history
        gc.collect();torch.cuda.empty_cache()
