"""Pinned public checkpoints. Verify bytes before loading pickle-based weights."""
from pathlib import Path
import hashlib, os, shutil

MANIFEST = {
 'Cosmos-Policy-LIBERO-Predict2-2B.pt': {
  'repo':'nvidia/Cosmos-Policy-LIBERO-Predict2-2B','revision':'cb689ec0e3347c13667d70a78a3447388f5c3bb8',
  'bytes':3913017345,'sha256':'8818528d8c9150cda0ddf8c711b0f221b21dac8ac379bd26d5690235954d33e2'},
 'Wan2.1_VAE.pth': {
  'repo':'Wan-AI/Wan2.1-T2V-1.3B','revision':'37ec512624d61f7aa208f7ea8140a131f93afc9a',
  'bytes':507609880,'sha256':'38071ab59bd94681c686fa51d75a1968f64e470262043be31f7a094e442fd981'},
 'uva_pusht.ckpt': {
  'gdrive_id':'1OduHcxfc2hqUYSccMQNf9g-vAt-q2UhF','bytes':1310420836,
  'sha256':'114dd771f946311fc72208439937009ad8a8f027a1e843ec42625d1cfe38bcbc'}
}

def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(8*1024**2),b''):h.update(chunk)
    return h.hexdigest()

def get_weights(default_root):
    root=Path(os.environ.get('SEMINAR07_WEIGHTS',Path(default_root)/'weights')).resolve()
    root.mkdir(parents=True,exist_ok=True)
    for name,item in MANIFEST.items():
        path=root/name
        if not path.exists():
            print('Downloading',name,flush=True)
            if 'repo' in item:
                from huggingface_hub import hf_hub_download
                cached=Path(hf_hub_download(item['repo'],name,revision=item['revision']))
                # Keep one copy of each large file on the Colab disk.
                path.symlink_to(cached.resolve())
            else:
                import gdown
                part=root/(name+'.part')
                gdown.download(id=item['gdrive_id'],output=str(part),quiet=False,resume=True)
                assert part.stat().st_size==item['bytes'],'Incomplete UVA download: rerun setup'
                assert digest(part)==item['sha256'],'UVA download checksum mismatch'
                part.replace(path)
        assert path.stat().st_size==item['bytes'],f'Unexpected size: {path}'
        assert digest(path)==item['sha256'],f'Checksum mismatch: {path}'
        print('SHA-256 OK:',name)
    return root
